///=============================================================================================================

#include"Integration.h"

///=============================================================================================================

int Lobotto_it,Lobotto_maxit,Lobotto_fit;

///=============================================================================================================

int signint(double is)
{
if(is<0)return -1;
if(is==0)return 0;
if(is>0)return 1;
}


/// Adaptive Lobotto Quadrature (complex)

complex<double> quadlstep(complex<double> (*f)(double[],double), const double a, const double b,
 complex<double> fa, complex<double> fb,complex<double> is,double par[])
  {
//cout<<"hi step \n";
Lobotto_it++;
double h, m, alpha, beta, mll, ml, mr, mrr,x[5];
complex<double> Q,fmll, fml, fm, fmr, fmrr, i1,i2,y[5];
    //vec x(5), y(5);
    h=(b-a)/2; m=(a+b)/2;
    alpha=sqrt(2.0/3); beta=1.0/sqrt(5.0);
    mll=m-alpha*h; ml=m-beta*h; mr=m+beta*h; mrr=m+alpha*h;
    x[0]=mll; x[1] = ml; x[2] = m; x[3] = mr; x[4] = mrr;

    //y=vec_function(f, x);
    for(int i=0;i<5;i++)
{
   y[i]=f(par,x[i]);
//cout<<i<<"                  "<<y[i]<<endl;
}
    fmll=y[0]; fml=y[1]; fm=y[2]; fmr=y[3]; fmrr=y[4];

    Lobotto_fit=Lobotto_fit+5;

    i2 = (h/6.0)*(fa+fb+5.0*(fml+fmr));
    i1 = (h/1470.0)*(77.0*(fa+fb)+432.0*(fmll+fmrr)+625.0*(fml+fmr)+672.0*fm);

    if( (real(is + (i1-i2)) == real(is) && imag(is + (i1-i2)) == imag(is))  || (mll<=a) || (b<=mrr) ) {

     /// DISP NOTHING
     if( (m <= a) || (b<=m) ) {
	//cout<<"  "<<"Interval contains no more machine number. Required tolerance may not be met\n";
      int tesdip=1;
      }
      Q = i1;
return Q;
    } else {
      Q=quadlstep(f, a, mll, fa, fmll, is,par) + quadlstep(f, mll, ml, fmll, fml, is,par) + quadlstep(f, ml, m, fml, fm, is,par) +
      quadlstep(f, m, mr, fm, fmr, is,par) + quadlstep(f, mr, mrr, fmr, fmrr, is,par) + quadlstep(f, mrr, b, fmrr, fb, is,par);
      if(Lobotto_fit>=Lobotto_maxit)return Q;
    }

    return Q;

  }

complex<double> quadl(complex<double> (*f)(double[],double), double a, double b, double par[],
					  double tol, int maxit, int *itn)
  {
//cout<<"hi \n";
double mfac=1.0;
if(a>b){double tem=a; a=b; b=tem;mfac=-1.0;}

Lobotto_maxit=maxit;
Lobotto_it=0;
Lobotto_fit=0;
double x[13],m, h, alpha, beta, x1, x2, x3, s, erri1, erri2, R;
complex<double> y[13],Q,fa, fb, i1, i2, is;
complex<double>CJ(0.0,1.0);
    //vec x(13), y(13);


    double tol2 = tol;

    m=(a+b)/2; h=(b-a)/2;

    alpha=sqrt(2.0/3); beta=1/sqrt(5.0);

    x1=.942882415695480; x2=.641853342345781; x3=.236383199662150;
    x[0]=a; x[1]=m-x1*h; x[2]=m-alpha*h; x[3]=m-x2*h;
    x[4]=m-beta*h; x[5]=m-x3*h; x[6]=m; x[7]=m+x3*h;
    x[8]=m+beta*h; x[9]=m+x2*h; x[10]=m+alpha*h;
    x[11]=m+x1*h; x[12]=b;

    //y=vec_function(f, x);

for(int i=0;i<13;i++) y[i]=f(par,x[i]);
Lobotto_fit=Lobotto_fit+13;
    fa=y[0]; fb=y[12];
    i2=(h/6.0)*(y[0]+y[12]+5.0*(y[4]+y[8]));
    i1=(h/1470.0)*(77.0*(y[0]+y[12])+432.0*(y[2]+y[10])+ 625.0*(y[4]+y[8])+672.0*y[6]);

    is=h*(.0158271919734802*(y[0]+y[12])+.0942738402188500*(y[1]+y[11])+.155071987336585*(y[2]+y[10])+
	  .188821573960182*(y[3]+y[9])+.199773405226859*(y[4]+y[8])+.224926465333340*(y[5]+y[7])
          +.242611071901408*y[6]);

double ris,iis;
ris=real(is);
iis=imag(is);
for(int i=0;i<2;i++)
{
  if(i==0)s=signint(ris);else s=signint(iis);

    if (s == 0.0)
      s = 1;
    if(i==0)
    {
    erri1 = fabs(real(i1-is));
    erri2 = fabs(real(i2-is));
    }
    else
    {

    erri1 = fabs(imag(i1-is));
    erri2 = fabs(imag(i2-is));
    }
    R=1;
    if (erri2 != 0.0)
      R = erri1/erri2;

    if (R>0 && R<1)
      tol2=tol2/R;

    if(i==0)
    {
    ris = s*fabs(ris)*tol2/std::numeric_limits<double>::epsilon();
    if (ris == 0.0)
      ris=b-a;
    }
    else
    {
    iis = s*fabs(iis)*tol2/std::numeric_limits<double>::epsilon();
    if (iis == 0.0)
    iis=b-a;
    }

}
is=ris+CJ*iis;

    Q = quadlstep(f, a, b, fa, fb, is,par);
    *itn=Lobotto_fit;
    return Q*mfac;
      }


///////////////////////////////  adaptive quadrature \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

void agq3 ( complex<double> sab, complex<double> (*f)(double[],double), double a, double b, double par[], double TOL,
            complex<double> *approx, double *errest, int *nfunc )

{
     double h2,c,eest,est1,est2;
     dcomplex fml,fpl,fmr,fpr,sac, scb,fcl,fcr,app1,app2;
     int nf1, nf2;

     h2 = ( b - a ) / 4.0;
     fml = f( par,a + h2 - sqrt(0.6) * h2 );
     fcl = f( par,a + h2 );
     fpl = f( par,a + h2 + sqrt(0.6) * h2 );
     fmr = f( par,b - h2 - sqrt(0.6) * h2 );
     fcr = f( par,b - h2 );
     fpr = f( par,b - h2 + sqrt(0.6) * h2 );
     sac = h2 * ( 5.0*fml + 8.0*fcl + 5.0*fpl ) / 9.0;
     scb = h2 * ( 5.0*fmr + 8.0*fcr + 5.0*fpr ) / 9.0;

     eest = abs ( sab - sac - scb );
     if ( eest < (42.0*TOL) ) {
        (*approx) = sac + scb;
        (*errest) = eest / 42.0;
        (*nfunc)  = 6;
     }
     else {
        agq3 ( sac, f, a, a+2.0*h2, par,TOL/2.0, &app1, &est1, &nf1 );
        agq3 ( scb, f, a+2.0*h2, b, par,TOL/2.0, &app2, &est2, &nf2 );
        (*approx) = app1 + app2;
        (*errest) = est1 + est2;
        (*nfunc)  = nf1  + nf2 + 6;
     }
}

complex<double> adapt_gq3 ( complex<double> (*f)(double[],double), double a, double b, double par[], double TOL, double *errest, int *nfunc )

{

     double h2;
     complex<double> fm, fp, sab,fc,approx;

	h2 = ( b - a ) / 2.0;
     fm = f( par,a + h2 - sqrt(0.6) * h2 );
     fc = f( par,a + h2 );
     fp = f( par,a + h2 + sqrt(0.6) * h2 );
     sab = h2 * ( 5.0*fm + 8.0*fc + 5.0*fp ) / 9.0;
     agq3 ( sab, f, a, b, par,TOL, &approx, errest, nfunc );
     (*nfunc) += 3;
	return approx;
}

///==========================  adaptive trapezoidal ruke ==================================\\

complex<double> trap(complex<double> (*f)(double[],double),double par[],double a, double b)
 {
   return (b-a)*(f(par,a)+f(par,b))/2.0;
 }

complex<double> adatraprule(complex<double> (*f)(double[],double),double par[],double a, double b,complex<double> sum, double tol,vector<double> &p)
{
	   complex<double> sr1, sr2;
	   double c, err;
  c = (a+b)/2;			/* else descend if necessary */
  //cout<<c<<endl;
  for(int i=0; i<p.size(); i++)
  {
 	 //cout<<"p before...\n";
 	 //for(int k=0; k<p.size();k++)
 	   //  	 cout<<p[k]<<endl;
 	 if(c<p[i+1] && c>p[i])
 	 {
 		 p.insert(p.begin()+i+1,c);
 		 //cout<<"p after...\n";
 	    	// for(int k=0; k<p.size();k++)
 	    	  //   	 cout<<p[k]<<endl;
 		 break;
 	 }
  }
  sr1 = trap(f,par,a,c);  sr2 = trap(f,par,c,b);
  err = abs(sr1+sr2 - sum);	/* test the current error */
  if(err<tol)			/* accuracy is achieved */
    sum = sr1+sr2;
  else				/* split the current interval */
    sum =
	 adatraprule(f,par,a,c,sr1,tol/2,p)
	 + adatraprule(f,par,c,b,sr2,tol/2,p);
  return sum;
}

complex<double>adatrap(complex<double> (*f)(double[],double), double par[],double a, double b,double tol,vector<double>&p)
		{
	complex<double> sum = trap(f,par,a, b);	/* start the recursion */
	p.resize(2);
	p[0]=a;
	p[1]=b;
	sum = adatraprule(f,par,a,b,sum,tol,p); /* recursive trapezoidal rule */
	return sum;
	}

//////////////////////////////////// COMPLEX \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


complex<double> adapt_glo3Step( complex<double> (*f) (double[],double),double a, double b,  complex<double> fa,
complex<double> fb, double par[],int &neval,int maxeval,double acc)
{
double beta  = 1.0/std::sqrt(5.0);
double h=(b-a)/2;
double m=(a+b)/2;
/* 3 point Gauss Lobotto rule */
complex<double> f0=f(par,m);
complex<double> integral2=(h/3.0)*(fa+fb+4.*f0);
if (neval >= maxeval)
{
cout<<"Maximum number of evaluations reached in GaussLobatto\n";
return integral2;
}
/* 4 point Gauss Lobotto rule */
double ml =m-beta*h;
double mr =m+beta*h;
complex<double> fml = f(par,ml);
complex<double> fmr  = f(par,mr);
complex<double> integral1=(h/6.0)*(fa+fb+5.*(fml+fmr));
neval+=3;
double estacc=abs(integral1-integral2);

// The volatile keyword should prevent the floating point destination value from being stored in extended precision
// registers which actually have a very different std::numeric_limits<double>::epsilon().

volatile double dist = acc + estacc;
if(dist==acc || ml<=a || b<=mr)
{
if (not (m>a && b>m))cout<<"Integration reached an interval with no more machine numbers\n";
return integral1;
}
else {
return  adapt_glo3Step(f, a, ml, fa, fml, par,neval, maxeval, acc)
+ adapt_glo3Step(f, ml, mr, fml, fmr, par,neval, maxeval, acc)
+ adapt_glo3Step(f, mr, b, fmr, fb, par,neval, maxeval, acc);
  }
}

complex<double> adapt_glo3( complex<double> (*f) (double [],double),double a, double b,double par[],double abstol, int maxeval, int *nf)
{
  const double tol_epsunit=abstol/numeric_limits<double>::epsilon();
  int neval=0;
   complex<double> ans= adapt_glo3Step(f, a, b,f(par,a), f(par,b),par,neval,maxeval,tol_epsunit);
			     //cout<<" neval="<<neval<<endl;
*nf=neval;
return ans;
}



////////////////////////////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

/// some definite integrals

dcomplex int_cos_gx_plus_h_mx_plus_c(dcomplex & g, dcomplex & h,dcomplex & M,dcomplex & C, double & x1, double & x2)
{
dcomplex g1=g*x1+h;
dcomplex g2=g*x2+h;
return (g*(M*x2+C)*sin(g2)+ M*cos(g2) -  (g*(M*x1+C)*sin(g1)+ M*cos(g1)))/(g*g);
}

dcomplex int_sin_gx_plus_h_mx_plus_c(dcomplex & g, dcomplex & h,dcomplex & M,dcomplex & C, double & x1, double & x2)
{
dcomplex g1=g*x1+h;
dcomplex g2=g*x2+h;
return (-g*(M*x2+C)*cos(g2)+ M*sin(g2) -  (-g*(M*x1+C)*cos(g1)+ M*sin(g1)))/(g*g);
}


dcomplex int_xpowerj_cos___g_h_x1_x2(int  n, dcomplex g, dcomplex  h, double & x1 , double & x2)
{
dcomplex jj(0.0,1.0);
double fn;//=factorial(n),fk;
dcomplex A1=0.0,B1=0.0,A2=0.0,B2=0.0;

double fk=1;
for(int k=0; k<=n; k++)
{
  //fk=factorial(k);
  if(k>0)fk=fk*k;
  //cout<<k<<" ... "<<fk<<endl;
  A1=A1+pow(jj*g*x1,k)/fk;
  A2=A2+pow(jj*g*x2,k)/fk;

  B1=B1+pow(-jj*g*x1,k)/fk;
  B2=B2+pow(-jj*g*x2,k)/fk;
}
fn=fk;
double PM=pow(-1.0,n);
dcomplex g1=g*x1+h;
dcomplex g2=g*x2+h;
dcomplex U=fn*pow(jj/g,n+1)/2.0;
return U*((PM*A2*exp(-jj*g2)-B2*exp(jj*g2))-(PM*A1*exp(-jj*g1)-B1*exp(jj*g1)));
}

dcomplex int_poly_cos___g_h_x1_x2(vcomplex & a, dcomplex g, dcomplex  h, double & x1 , double & x2)
{
dcomplex jj(0.0,1.0);
dcomplex sum=0.0;
dcomplex A1=0.0,B1=0.0,A2=0.0,B2=0.0;
dcomplex g1=g*x1+h;
dcomplex g2=g*x2+h;
dcomplex U,PM;
double fk=1;
for(int k=0; k<a.size(); k++)
{
  if(k>0)fk=fk*k;
  //fk=factorial(k);
  //cout<<k<<" ... "<<fk<<endl;
  A1=A1+pow(jj*g*x1,k)/fk;
  A2=A2+pow(jj*g*x2,k)/fk;
  B1=B1+pow(-jj*g*x1,k)/fk;
  B2=B2+pow(-jj*g*x2,k)/fk;
  U=fk*pow(jj/g,k+1)/2.0;
  PM=pow(-1.0,k);
  //cout<<a[k]<<"   "<<endl;
  sum=sum+a[k]*U*((PM*A2*exp(-jj*g2)-B2*exp(jj*g2))-(PM*A1*exp(-jj*g1)-B1*exp(jj*g1)));
  //sum=sum+a[k]*int_xpowerj_cos___j_g_h_x1_x2(k, g, h, x1 , x2);
}
//cout<<a.size()<<"    "<<sum<<endl;
return sum;
}

/// definite integral[x1,x2]{intergrand = cos(g*x+h)*(a0+a1*x+a2*x^2+........a[s-1]*x^(s-1))*sqrt(x)}dx, s=a.size()-1;
dcomplex int_poly_by_sqrt_x_cos___g_h_x1_x2_nterm(vcomplex & a, dcomplex g, dcomplex  h, double & x1 , double & x2, int nterm)
{
dcomplex jj(0.0,1.0);
dcomplex U,A1,A2,B1,B2,tgpn1,tgpn2,MON;
dcomplex g1=g*x1+h;
dcomplex g2=g*x2+h; //-p1
dcomplex igx1=jj*g*x1;
dcomplex igx2=jj*g*x2;
double p,tgp;
dcomplex sum=0.0,mop;

for(int k=0; k<a.size(); k++)
{
p=k-0.5;
mop=pow(jj,2.0*p); // pow(-1,p)
U=tgamma(1+p)*mop*pow(jj,2.*p+1.);
//cout<<p<<"  "<<pow(-1.0,p)<<endl;
A1=0.0;
A2=0.0;
B1=0.0;
B2=0.0;
for(int n=0; n<nterm; n++)
{
tgp=tgamma(p+1.-n);
MON=pow(-1.,-n);
tgpn1=pow(igx1,-n)/tgp;
tgpn2=pow(igx2,-n)/tgp;
A1=A1+tgpn1;
A2=A1+tgpn2;
B1=B1+MON*tgpn1;
B2=B2+MON*tgpn2;
//cout<<A1<<"  "<<A2<<"  "<<B1<<"  "<<B2<<endl;
}
//cout<<U<<"  "<<exp(-jj*g2)<<"  "<<exp(-jj*g1)<<"   "<<exp(jj*g2)<<"  "<<exp(jj*g1)<<endl;
sum=sum+a[k]*U*(pow(x2,p)*(exp(-jj*g2)*A2-exp(jj*g2)*B2)- pow(x1,p)*(exp(-jj*g1)*A1-exp(jj*g1)*B1));
}
return sum/(2.0*g);
}
/* .............................................................................*/
/// Integral{x1,x2}[ exp(b*x)*cos(g*x) ]
dcomplex int_exp_bx_cos_g_h___b_g_h_x1_x2(dcomplex & b, double & g,double & h, double & x1, double & x2)
{
 double g1=g*x1+h;
 double g2=g*x2+h;
 return (exp(b*x2)*(b*cos(g2)+g*sin(g2))-exp(b*x1)*(b*cos(g1)+g*sin(g1)))/(g*g+b*b);
}
/// Integral{x1,x2}[ exp(b*x)*sin(g*x) ]
dcomplex int_exp_bx_sin_g_h___b_g_h_x1_x2(dcomplex & b, double & g,double & h, double & x1, double & x2)
{
 double g1=g*x1+h;
 double g2=g*x2+h;
 return (exp(b*x2)*(b*sin(g2)-g*cos(g2))-exp(b*x1)*(b*sin(g1)-g*cos(g1)))/(g*g+b*b);
}
/// integral[@ x1]{intergrand = cos(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_cos_g_h___b_g_h_x1(dcomplex & b, double & g,double & h, double & x1)
{
double g1=g*x1+h;
return exp(b*x1)*(b*cos(g1)+g*sin(g1))/(g*g+b*b);
}
/// integral[@ x1]{intergrand = sin(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_sin_g_h___b_g_h_x1(dcomplex & b, double & g,double & h, double & x1)
{
double g1=g*x1+h;
return exp(b*x1)*(b*sin(g1)-g*cos(g1))/(g*g+b*b);
}

