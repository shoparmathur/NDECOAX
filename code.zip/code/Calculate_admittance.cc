// Calculate_reflection.cc (Source file)//-----------------
//
#include "Calculate_admittance.h"
#include "Integration.h"
#include "LayeredMedia.h"

LayeredMedia *LMP;

//Setting parameter for Adaptive Gauss Lobotto Quadrature //--------------------------- 
complex<double> integrand_lm_sing(double *par,double theta)
{
complex<double>beta(0.5*LMP->ael*(1.-cos(theta)), LMP->bel*sin(theta));
complex<double>dbeta(0.5*LMP->ael*sin(theta), LMP->bel*cos(theta));
return LMP->integrand_lm(beta)*dbeta;
}

complex<double> integrand_lm_tail(double *par,double t)
{
complex<double>beta(1.0/cos(t),0.0);
complex<double>dbeta(tan(t)/cos(t), 0.0);
return LMP->integrand_lm(beta)*dbeta;
}

//Calculating reflection coefficient//--------------------
/*complex<double> reflection(complex<double>Ya)
{
	complex<double> s11=(LMP->Ycwg-Ya)/(LMP->Ycwg+Ya);
	//cout<<"LMP->zcwg="<<abs(s11)<<endl;
	//exit(0);
	return s11;
}*/

// Adaptive Gauss Lobotto Quadrature elliptical integral//-------------------------------------
complex<double> Yellipse(LayeredMedia & LM,double err,int maxit)
{
LMP=&LM;
// integration over ellispe
double *par;
return quadl(integrand_lm_sing, 0.0,M_PI,par, err, maxit, &LMP->nitellipse);
}

// Adaptive Gauss Lobotto Quadrature Tail integration//--------------------------------------
complex<double> Ytail(LayeredMedia & LM,double err,int maxit)
{
LMP=&LM;
// integration over tail------------------------------------------
double *par;
int nitn;
return quadl(integrand_lm_tail, acos(1.0/LMP->ael),M_PI/2.0,par, err, maxit,&LMP->nittail);
}





