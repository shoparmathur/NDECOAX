//
// LayeredMedia.h   ( Header file)

//
#ifndef LayeredMedia_h
#define LayeredMedia_h 1

#include<iostream>
#include<fstream>
#include<math.h>
#include<vector>
#include<complex>
#include<iomanip>
using namespace std;



// declaration of the functions in class Layered media-------------//

// Class LayeredMedia//---------------------------------------------------
class LayeredMedia
{
public:
complex<double>jj;
vector<double> thickness,mu;
vector< complex<double> > eps;
double f,k0,k0air,mu0,eps0,ael,bel,afrac,bfrac,epsmax,consint,ra,rb,epscwg,Ycwg;
int nitellipse,nittail;

// Constructor//-----------------
LayeredMedia();
// Coaxial probe parameter calculations//-----------------------------------------------
void coaxial_rad_epsr_f(double rad_a,double rad_b, double eps,double f_);
//counting number of layers//--------------------------------
int nlayer();
// Adding layers information//----------------------------------------------------
void add_layer(double t, double eps_, double mu_, double lt);//   thickness,epsilon,muo and losstangent//--------------------------
//// TM and TE modes parameter calculations//--------------------------------------------------
complex<double> YT(char type,complex<double> beta);
// Limits of elliptical path//----------------------------------------------
void ellipse_sing(double afrac_,double bfrac_);
//  coefficient for TM and TE incidence//------------------------------------------
complex<double> integrand_lm(complex<double>beta);
};

#endif




