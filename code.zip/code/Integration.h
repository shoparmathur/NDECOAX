///=============================================================================================================
#ifndef INTEGRATE_
#define INTEGRATE_ 1
#include<iostream>
#include<complex>
#include<math.h>
#include<limits>
#include<vector>
using namespace std;
typedef complex <double> dcomplex;
typedef vector<double> vdouble;
typedef vector < complex<double> > vcomplex;
///=============================================================================================================
int signint(double is);
/// Adaptive Lobotto Quadrature (complex)
complex<double> quadlstep(complex<double> (*f)(double[],double), const double a, const double b,
 complex<double> fa, complex<double> fb,complex<double> is,double par[]);
complex<double> quadl(complex<double> (*f)(double[],double), double a, double b, double par[], double tol, int maxit, int *itnsol);

/// gauss quadrature
complex<double> adapt_gq3 ( complex<double> (*f)(double[],double), double a, double b, double par[], double TOL, double *errest, int *nfunc );

/// Adaptive Lobotto Quadrature (+3 eval)
complex<double> adapt_glo3( complex<double> (*f) (double [],double),double a, double b,double par[],double abstol, int maxeval, int *nf);

/// Adaptive trapezoidal method
complex<double>adatrap(complex<double> (*f)(double[],double), double par[],double a, double b, double tol,vector<double>&p);

///=============================================================================================================

int tri_int_sing_equality(double a, double b);
//void tri_int_sing_analytical(vec3 q1,vec3 q2,vec3 q3, vec3 r,double *K1M1_, vec3 &K2M1o);

///=============================================================================================================

/// definite integral[x1,x2]{intergrand = cos(g*x+h)*(m*x+c)} dx
dcomplex int_cos_gx_plus_h_mx_plus_c(dcomplex & g, dcomplex & h,dcomplex & M,dcomplex & C, double & x1, double & x2);
/// definite integral[x1,x2]{intergrand = sin(g*x+h)*(m*x+c)} dx
dcomplex int_sin_gx_plus_h_mx_plus_c(dcomplex & g, dcomplex & h,dcomplex & M,dcomplex & C, double & x1, double & x2);
/// definite integral[x1,x2]{intergrand = cos(g*x+h)*x^n} dx
dcomplex int_xpowerj_cos___g_h_x1_x2(int  n, dcomplex g, dcomplex  h, double & x1 , double & x2);
/// definite integral[x1,x2]{intergrand = cos(g*x+h)*(a0+a1*x+a2*x^2+........a[s-1]*x^(s-1))}dx, s=a.size()-1;
dcomplex int_poly_cos___g_h_x1_x2(vcomplex & a, dcomplex g, dcomplex  h, double & x1 , double & x2);
/// definite integral[x1,x2]{intergrand = cos(g*x+h)*(a0+a1*x+a2*x^2+........a[s-1]*x^(s-1))*sqrt(x)}dx, s=a.size()-1;
dcomplex int_poly_by_sqrt_x_cos___g_h_x1_x2_nterm(vcomplex & a, dcomplex g, dcomplex  h, double & x1 , double & x2, int nt);
/// definite integral[x1,x2]{intergrand = cos(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_cos_g_h___b_g_h_x1_x2(dcomplex & b, double & g,double & h, double & x1, double & x2);
/// definite integral[x1,x2]{intergrand = sin(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_sin_g_h___b_g_h_x1_x2(dcomplex & b, double & g,double & h, double & x1, double & x2);
/// integral[@ x1]{intergrand = cos(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_cos_g_h___b_g_h_x1(dcomplex & b, double & g,double & h, double & x1);
/// integral[@ x1]{intergrand = sin(g*x+h)*exp(b*x)} dx
dcomplex int_exp_bx_sin_g_h___b_g_h_x1(dcomplex & b, double & g,double & h, double & x1);
#endif

