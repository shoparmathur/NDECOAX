// Calculate_admittance.h (header file)//-----------------
//
#include<iostream>
#include<fstream>
#include<math.h>
#include<vector>
#include<complex>
#include<iomanip>
#include "LayeredMedia.h"
using namespace std;


//Setting parameter for Adaptive Gauss Lobotto Quadrature //--------------------------- 
complex<double> integrand_lm_sing(double *par,double theta);


//Calculating reflection coefficient//--------------------
//complex<double> reflection(complex<double>Ya);

// Adaptive Gauss Lobotto Quadrature elliptical integral//-------------------------------------
complex<double> Yellipse(LayeredMedia & LM,double err,int maxit);


// Adaptive Gauss Lobotto Quadrature Tail integration//--------------------------------------
complex<double> Ytail(LayeredMedia & LM,double err,int maxit);

// Plotting using Gnuplot//------------------------------
void gnuplot_load(string fn);
void plot_file();





