#include<iostream>
#include<fstream>
#include<math.h>
#include<vector>
#include<complex>
#include "Bessel.h"
#include "Integration.h"
#include "LayeredMedia.h"
#include "Calculate_admittance.h"
#include "Gnuplot_interface.h"
#include<iomanip>
using namespace std;
vector<double> linspace_fixed_step_(double xa,double xb,double dx)
{
vector<double> x(0);
for(int i=0;i<(i+3);i++)
{
x.push_back(xa+dx*i);
if(x[x.size()-1]>=xb)break;
}
return x;
}

// Main file//---------------------------
main()
{
// Reading data for Lossy Stratified mediumfrom the file methanol.txt//----------------------------------------------
int N=17;
double f_,eps_1,tandel_1;
ifstream fin;
fin.open("methanol.txt");
string  fr;
getline(fin,fr);
vector<double> f_lossy(N),epsilon(N),tandel(N);
for(int i=0;i<N;i++)
{
fin>>f_>>eps_1>>tandel_1;
f_lossy[i]=f_;
epsilon[i]=eps_1;
tandel[i]=tandel_1;
}
fin.close();


// opening output file for storing the data for lossy and lowloss medium//-------------------------
ofstream fout_lossy,fout_lowloss;
fout_lossy.open("multilayer_lossy.txt");
fout_lowloss.open("multilayer_lowloss.txt");
fout_lossy<<"# f"<<"	"<<"Ya(real)"<<setw(10)<<"Ya(imag)"<<endl;
fout_lowloss<<"# f"<<"	"<<"Ya(real)"<<setw(10)<<"Ya(imag)"<<endl;

// Low loss stratified medium//---------------------------------------
//frequency sweep//-------------------------------------
vector<double> f_lowloss=linspace_fixed_step_(1e9,6e9,0.1e9);


// initialization of layered medium for  lowloss stratified medium//-----------------------
LayeredMedia LM_lowloss;
LM_lowloss.add_layer(3.175*.001,7.3,1.,0.04);// Layer 1
LM_lowloss.add_layer(4*.001,2.,1.,0.0003);// Layer 2
LM_lowloss.add_layer(11*.001,2.6,1.,0.00043);// Layer3
LM_lowloss.add_layer(-1,1.,1.,0);// Air backing//-------------------------------------------------


LM_lowloss.ellipse_sing(1.1,1e-12);// Specify the elliptical path borders//-----------------------------------------



// Lowloss medium calculations//------------------------------------------

for(int i=0; i<f_lowloss.size(); i++)
{
LM_lowloss.coaxial_rad_epsr_f(.13*0.001,.95*0.001,5.5,f_lowloss[i]);// Dimension of OECL//---------------
complex<double>Ye=Yellipse(LM_lowloss,1e-9,100000);// elliptical integral//-------------------------------------
complex<double>Yt=Ytail(LM_lowloss,1e-9,100000);// Tail integration//--------------------------------------
complex<double>Ya=Ye+Yt;// Aperture admittance value//--------------------------------------
complex<double>sa=(Ya);


// Saving in the file //--------------------------------------------------------------------------

fout_lowloss<<f_lowloss[i]<<"	"<<real(Ya)<<setw(10)<<"	"<<imag(Ya)<<endl;
}

// Lossy medium calculations//------------------------------

// Lossy stratified medium//---------------------------------------

for(int i=0; i<f_lossy.size(); i++)
{
LayeredMedia LM_lossy;
// Add different layers//---------------------------------------
LM_lossy.add_layer(70.*0.001,epsilon[i],1.,tandel[i]);// ------------thickness in mm//----------------------------------
LM_lossy.add_layer(-1,1.,1.,0);// Air sbacking//-------------------------------------------------
LM_lossy.ellipse_sing(1.1,1e-12);// Specify the elliptical path borders//-----------------------------------------
LM_lossy.coaxial_rad_epsr_f(0.4*0.001,1.14*0.001,1.58,f_lossy[i]);// Dimension of OECL//---------------
complex<double>Ye=Yellipse(LM_lossy,1e-5,10000);// elliptical integral//-------------------------------------
complex<double>Yt=Ytail(LM_lossy,1e-9,10000);// Tail integration//--------------------------------------
complex<double>Ya=Ye+Yt;// Aperture admittance value//--------------------------------------

// Saving in the file //--------------------------------------------------------------------------
fout_lossy<<f_lossy[i]<<setw(10)<<"	"<<real(Ya)<<setw(10)<<"	"<<imag(Ya)<<endl;

}

// closing the files//--------------------------

fout_lowloss.close();

fout_lossy.close();
// Plotting the results using Gnuplot
plot_file();
}
