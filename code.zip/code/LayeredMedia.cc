

// LayeredMedia.cc (Source file)//-----------------
//
#include "LayeredMedia.h"
#include "Bessel.h"

// definition of member function is already declared in class//
LayeredMedia::LayeredMedia()
{
thickness.resize(0);
mu.resize(0);
eps.resize(0);
complex<double>jjj(0.,1);
jj=jjj;
eps0=8.8544187817e-12;
mu0=4.*M_PI*1e-7;
epsmax=-1;
consint=(2.*M_PI);

}



// Coaxial probe parameter calculations//-----------------------------------------------
void LayeredMedia::coaxial_rad_epsr_f(double rad_a, double rad_b,double eps,double f_)
{
nitellipse=0;
nittail=0;
f=f_;
k0=2.0*M_PI*f*sqrt(eps)/(2.998e8);
k0air=2.0*M_PI*f/(2.998e8);
ra=rad_a;
rb=rad_b;
epscwg=eps;
ael=afrac*sqrt(epsmax);
bel=bfrac*k0;
Ycwg=sqrt(eps*eps0/mu0)*(2*M_PI/(log(rb/ra)*log(rb/ra)));
//cout<<"yCWG="<<log(rb/ra)<<endl;
//exit(0);
}

int LayeredMedia::nlayer(){return mu.size();}
// Adding layers information//----------------------------------------------------
void LayeredMedia::add_layer(double t, double eps_, double mu_, double lt)//   thickness,epsilon,muo and losstangent//--------------------------
{
thickness.push_back(t);
eps.push_back(eps_*eps0*(1.-jj*lt));	
mu.push_back(mu_*mu0);	
if(eps_>epsmax)epsmax=eps_;
}
// TM  parameter calculations//--------------------------------------------------
complex<double> LayeredMedia::YT(char type,complex<double> beta)
{
if(abs(beta)==1.0){cout<<"# error!"<<endl;} //exit(0);}// branch point//---------------------------
int ind=nlayer()-1;
complex<double>ytmte_,yi,ybetai,angi,kzi,Ni;
double omega=2.0*M_PI*f;
for(int i=ind; i>=0; i--)
{
 Ni=sqrt(eps[i]/eps0);
//cout<<"epsilon"<<i<<"="<<eps[i]/eps0<<endl;

yi=sqrt(eps0/mu0);// Free space admittance//----------------------------------

// Parameter calculation for TM  polarization//
if(type=='M') ybetai=yi*Ni*Ni/sqrt(Ni*Ni-beta*beta*epscwg);
kzi=k0air*sqrt(Ni*Ni-(epscwg*beta*beta));
//cout<<"yi="<<1./ybetai<<endl;

// Last layer is air//-------------------------

if(thickness[i]<0)
{

if(type=='M') ytmte_=yi*Ni*Ni/sqrt(Ni*Ni-beta*beta*epscwg);// admittance of last layer will be the input impedance of  TM//----------

}
else
{
angi=kzi*thickness[i];
ytmte_=ybetai*(ytmte_+jj*ybetai*tan(angi))/(ybetai+jj*ytmte_*tan(angi));// Transmission line model//--------------
}
//cout<<"beta="<<beta<<endl;
}

//exit(0);
return ytmte_;
}
// Limits of elliptical path//----------------------------------------------
void LayeredMedia::ellipse_sing(double afrac_,double bfrac_)
{
afrac=afrac_;
bfrac=bfrac_;
}

//  coefficient for TM  incidence//------------------------------------------
complex<double> LayeredMedia::integrand_lm(complex<double>beta)
{
double k0a=k0*ra;
double k0b=k0*rb;
complex<double> k0abeta=k0a*beta;
complex<double> k0bbeta=k0b*beta;
complex<double>J0_a=besselj0(k0abeta);
//cout<<"J0="<<J0_a<<endl;
//exit(0);
complex<double>J0_b=besselj0(k0bbeta);
complex<double> r;
if(abs(beta)==0.0)r=0 ; else r=YT('M',beta)*pow((J0_b-J0_a),2)/beta;
//r=YT('M',beta)*pow((J0_b-J0_a),2)/beta;
return r*consint/(log(rb/ra)*log(rb/ra));
}


