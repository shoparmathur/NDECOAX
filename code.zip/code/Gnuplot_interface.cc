
// Gnuplot_interface.cc (Source file)//-----------------
//
#include "Gnuplot_interface.h"


// Plotting the figure using Gnuplot interface//---------------------------:
void gnuplot_load(string fn)
{
string comand="gnuplot -persist\n";
FILE *pipe= popen(comand.c_str() , "w");
ostringstream oss;
oss.str(""); oss.clear();
oss<<"load '"<<fn<<"'"<<endl;
fprintf(pipe, "%s",oss.str().c_str());
fflush(pipe);
int r=pclose(pipe);
if(r<0)cout<<"# error in pclose(), while using unix pipes!"<<endl;
}


/// Plot the figure-------------------------------------------


void plot_file()
{

ofstream fout,fout1;
fout.open("fgnuplot");
fout1.open("fgnuplot1");
//  Plotting result for lossy dielectric medium comparing with experiemnt published in [9]-----//-------------------------------
fout<<"reset"<<endl;
fout<<"set term postscript enhanced eps color dashed dl 1  font 'Helvetica, 20'"<<endl; // for solid colors
fout<<"set output 'misra_real.eps'"<<endl;
fout<<"set key box at screen 0.55, screen 0.92 spacing 3 width 0.4 font 'Helvetica, 18'"<<endl;
//fout<<"set key below"<<endl;
fout<<"set grid lt 2 lw .3 lc rgb '#CCCCCC'"<<endl;
fout<<"set xlabel 'Frequency, GHz'"<<endl;
fout<<"set ylabel 'Re[ Y_A ]'"<<endl;
fout<<"set yrange [0:0.014]"<<endl;
//0080FF   556B2F
fout<<"plot 'multilayer_lossy.txt' u($1/1e9):2 w l lt 1 lc rgb '#228B22' lw 2.5 t 'Proposed Model','misra_admittance.txt' u 1:2 w p pt 7 ps 1.5 lc rgb '#0080FF' t 'Experiment' "<<endl; 
//fout<<"set key below"<<endl;
fout<<"set ylabel 'Im(Y_{A})'"<<endl;
fout<<"set output 'misra_imag.eps'"<<endl;
fout<<"set key box spacing 3 width 0.4"<<endl;
fout<<"set grid"<<endl;
fout<<"plot'multilayer_lossy.txt' u($1/1e9):3 w lp lt 2 lw 2 lc 3 t 'Proposed Model','misra_admittance.txt' u 1:3 w p pt 7 ps 2 t 'Experiment"<<endl;
fout.close();


//  Plotting result for lossless three layer stratified dielectric medium comparing with FEM results//-------------------------------
fout1<<"reset"<<endl;
fout1<<"set term postscript enhanced eps color dashed dl 3  font 'Helvetica, 16'"<<endl; // for solid colors
fout1<<"set output 'lossless_real.eps'"<<endl;
fout1<<"set key spacing 3 width 0.4"<<endl;
fout1<<"set xlabel 'Fre(GHz)'"<<endl;
fout1<<"set ylabel 'Re(Y_{A})'"<<endl;
fout1<<"set grid"<<endl;
fout1<<"set yrange [-0.0005:0.0006]"<<endl;
fout1<<"set xrange [1:6]"<<endl;
fout1<<"plot 'multilayer_lowloss.txt' u($1/1e9):2 every 3 w lp lt 2 lc 3 lw 2 ps 2 t 'Proposed Model','FEM_result.txt' u 1:2 every 3 w p pt 7 ps 2 t 'FEM' "<<endl; 
fout1<<"set output 'lossless_imag.eps'"<<endl;
fout1<<"set yrange [-0.0005:0.006]"<<endl;
fout1<<"set key spacing 3 width 0.4"<<endl;
fout1<<"set ylabel 'Im(Y_{A})'"<<endl;
fout1<<"plot 'multilayer_lowloss.txt' u($1/1e9):3 every 3 w lp lt 2 lw 2 lc 3 ps 2 t 'Proposed Model','FEM_result.txt' u 1:3 every 3 w p pt 7 ps 2 t 'FEM'"<<endl;
fout1.close();
gnuplot_load("fgnuplot");
gnuplot_load("fgnuplot1");
}


