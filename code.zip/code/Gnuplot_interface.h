// Gnuplot_interface.h.h (header file)//-----------------
//
#include<iostream>
#include<fstream>
#include<sstream>
#include<complex>
#include<iomanip>

using namespace std;

// Plotting the figure using Gnuplot interface//---------------------------:
void gnuplot_load(string fn);


/// Plot the figure//----------------------

void plot_file();
