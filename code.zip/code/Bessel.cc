#include "Bessel.h"
/// Complex Bessel

double bessel_a[12]={-.703125e-01,.112152099609375e+00,-.5725014209747314e+00,.6074042001273483e+01,-.1100171402692467e+03,
.3038090510922384e+04,-.1188384262567832e+06,.6252951493434797e+07,-.4259392165047669e+09,.3646840080706556e+11,-.3833534661393944e+13,
.4854014686852901e+15};
double bessel_b[12]={.732421875e-01,-.2271080017089844e+00,.1727727502584457e+01,-.2438052969955606e+02,.5513358961220206e+03,
-.1825775547429318e+05,.8328593040162893e+06,-.5006958953198893e+08,.3836255180230433e+10,-.3649010818849833e+12,
.4218971570284096e+14,-.5827244631566907e+16};
double bessel_a1[12]={.1171875e+00,-.144195556640625e+00,.6765925884246826e+00,-.6883914268109947e+01,.1215978918765359e+03,
-.3302272294480852e+04,.1276412726461746e+06,-.6656367718817688e+07,.4502786003050393e+09,-.3833857520742790e+11,
.4011838599133198e+13,-.5060568503314727e+15};
double bessel_b1[12]={-.1025390625e+00,.2775764465332031e+00,-.1993531733751297e+01,.2724882731126854e+02,
-.6038440767050702e+03,.1971837591223663e+05,-.8902978767070678e+06,.5310411010968522e+08,-.4043620325107754e+10,
.3827011346598605e+12,-.4406481417852278e+14,.6065091351222699e+16};

complex<double> bessel_ci(0.0,1.0);
double bessel_el=0.5772156649015329;
double bessel_rp2=2.0/M_PI;


///  J1(complex<doble> z)
complex<double>besselj1(complex<double>z)
{
return cbessj1(z);
}
//  cbessj1(z)//----------------------
complex<double>cbessj1(complex<double>z)
{
complex<double>cbj1,cr;
double a0=abs(z);

if(a0 == 0.0)
{
cbj1=complex<double>(0.0,0.0);
return cbj1;
}

complex<double>z2=z*z;
complex<double>z1=z;
if(real(z)< 0.0)z1=-z;

if(a0 <= 12.0)
{
cbj1=1.0;
cr=1.0;
for  (int k=1;k<=40;k++)
{
cr=-0.25*cr*z2/(k*(k+1.0));
cbj1=cbj1+cr;
if(abs(cr)< abs(cbj1)*1.0e-15){break;}
}
cbj1=0.5*z1*cbj1;
}
else
{
complex<double>ct1,ct2,cp1,cu,cq1;
int k;
int k0=12;
if(a0 >= 35.0)k0=10;
if(a0 >= 50.0)k0=8;
ct1=z1-.25*M_PI;

cu=sqrt(bessel_rp2/z1);

ct2=z1-.75*M_PI;
cp1=complex<double>(1.0,0.0);
cq1=0.375/z1;

for  (k=1;k<=k0;k++)
{
cp1=cp1+bessel_a1[k]*pow(z1,-2.*k);
cq1=cq1+bessel_b1[k]*pow(z1,-2.*k-1);
}

cbj1=cu*(cp1*cos(ct2)-cq1*sin(ct2));

}
if(real(z)< 0.0)cbj1=-cbj1;

return cbj1;
}
//---------------------------//


///  J2(complex<double> z)
complex<double>besselj2(complex<double>z)
{
return (2.0/z)*besselj1(z)-besselj0(z);
}




/// Complex Bessell (J0(complex<double> z)))

complex<double> besselj0(complex<double>z)
{
// n= order
double a0=abs(z);
complex<double>cbj0;

if(a0 == 0.0)
{
cbj0=complex<double>(1.0,0.0);
return cbj0;
}

complex<double>z2=z*z;
complex<double>z1=z;
if(real(z)< 0.0)z1=-z;

if(a0 <= 12.0)
{
cbj0=1.0;
complex<double>cr=1.0;

for  (int k=1;k<=40;k++)
{
cr=-0.25*cr*z2/double(k*k);
cbj0=cbj0+cr;
if(abs(cr)< abs(cbj0)*1.0e-15){break;}
}
}
else
{
complex<double>ct1,cq0,cu,cp0;
int k;
int k0=12;
if(a0 >= 35.0)k0=10;
if(a0 >= 50.0)k0=8;

ct1=z1-.25*M_PI;
cp0=complex<double>(1.0,0.0);
cq0=-0.125/z1;

for  (k=1;k<=k0;k++)
{
cq0=cq0+bessel_b[k]*pow(z1,-2.*k-1);
cp0=cp0+bessel_a[k]*pow(z1,-2.*k);
}
cu=sqrt(bessel_rp2/z1);
cbj0=cu*(cp0*cos(ct1)-cq0*sin(ct1));
}

return cbj0;

}
